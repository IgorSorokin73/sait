python manage.py runserver

лог: admin
пароль: 1

pip install -r requirements.txt