from django.contrib import admin
from . import models


@admin.register(models.RimCard)
class RimCardAdmin(admin.ModelAdmin):
    """Карточка диска"""
    list_display = ('rimcard_title', 'rimcard_description', 'rimcard_img', 'rimcard_price')

@admin.register(models.RequestForm)
class RequestFormAdmin(admin.ModelAdmin):
    """Заявка"""
    list_display = ('id', 'name', 'number')
