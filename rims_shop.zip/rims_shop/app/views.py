from django.shortcuts import render
from django.urls import reverse_lazy
from .models import RimCard, RequestForm
from django.views.generic import CreateView
from .forms import RequestsForm

# Create your views here.

def render_index(request):
    rims_cards = RimCard.objects.all()
    return render(request, 'index.html', {
        'rims_cards': rims_cards,
    })

class RequestFormCreateView(CreateView):
    template_name = 'crud.html'
    model = RequestForm
    form_class = RequestsForm
    raise_exception = True
    success_url = reverse_lazy('app:index')
