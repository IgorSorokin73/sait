from django.db import models


class RimCard(models.Model):
    rimcard_id = models.AutoField(primary_key=True)
    rimcard_title = models.CharField(max_length=100, default='Крутой дисок', verbose_name='Название')
    rimcard_description = models.TextField(default='', verbose_name='Описание')
    rimcard_img = models.ImageField(upload_to='media/', verbose_name='Фото')
    rimcard_price = models.IntegerField(default=0, verbose_name='Цена')

    def __str__(self) -> str:
        return self.rimcard_title
    
class RequestForm(models.Model):
    id = models.AutoField(primary_key=True)
    number = models.CharField(max_length=12, verbose_name='Номер телефона')
    name = models.CharField(max_length=100, default='Игорь Сергеевич', verbose_name='Имя')

    def __str__(self) -> str:
        return str(id)
    