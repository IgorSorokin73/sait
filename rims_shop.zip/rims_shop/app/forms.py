from django.forms import ModelForm
from .models import *


class RequestsForm(ModelForm):
    class Meta:
        model = RequestForm
        fields = ('id', 'number', 'name')