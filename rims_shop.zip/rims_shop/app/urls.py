from django.urls import path
from . import views
from django.contrib.auth.views import LogoutView

app_name = 'app'
urlpatterns = [
    path('', views.render_index, name='index'),
    path('call/', views.RequestFormCreateView.as_view(), name='call'),
]