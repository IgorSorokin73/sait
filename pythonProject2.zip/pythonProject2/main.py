import os

print('Команды:')
print('S - сканировать каталог')
print('W - удалить дубли')
print('A - добавить файл')
print('E - изменить файл')
print('V - просмотреть файл')
print('D - удалить файл')
print('X - завершить работу')
print()
directory = os.getcwd()
print('Сейчас Вы в каталоге:', directory)
cmd = input('Введите команду: ')
while cmd.upper() in 'SAEVWDP':
    if cmd.upper() == 'S':
        lifiles = os.listdir(path=".")
        print('\n'.join(sorted(lifiles)))
    elif cmd.upper() == 'A':
        file_name = input('Введите имя нового файла: ')
        if os.access(directory, os.W_OK):
            with open(file_name, "w") as f:
                f.write("Это текстовый файл")  # запить текста в этот файл
    elif cmd.upper() == 'E':
        file_name = input('Введите имя файла для изменения: ')
        file_path = os.path.join(directory, file_name)
        if os.path.exists(file_path):
            with open(file_name, "a") as f:
                f.write('\nСтрока для добавления')
    elif cmd.upper() == 'V':
        file_name = input('Введите имя файла для чтения: ')
        file_path = os.path.join(directory, file_name)
        if os.path.exists(file_path):
            with open(file_path, 'r') as f:
                print(''.join(f.readlines()))
    elif cmd.upper() == 'D':
        file_name = input('Введите имя файла для удаления: ')
        file_path = os.path.join(directory, file_name)
        if os.path.exists(file_path):
            print('Удаляю файл:', file)
            os.remove(file_path)
    elif cmd.upper() == 'W':
        lifiles = os.listdir(path=".")
        difiles = dict()
        for file in lifiles:
            file_path = os.path.join(directory, file)
            if os.path.exists(file_path) and not os.path.isdir(file_path):
                size = os.path.getsize(file_path)
                mtime = os.stat(file_path).st_mtime
                li = difiles.get(f'{mtime}{size}', [])
                li.append(file)
                difiles[f'{mtime}{size}'] = li
        for key, value in difiles.items():
            if len(value) > 1:
                value = sorted(value, key=lambda name: len(name))  # сортировка по длинне имени файла
                i = 0
                while i < len(value) - 1:
                    k = i + 1
                    while k < len(value):
                        fpath1 = os.path.join(directory, value[i])
                        fpath2 = os.path.join(directory, value[k])
                        file1 = open(fpath1, 'rb')
                        file2 = open(fpath2, 'rb')
                        data1 = file1.read()
                        data2 = file2.read()
                        file1.close()
                        file2.close()
                        if data1 == data2 and os.path.exists(fpath2):
                            print('Удаляю файл:', value[k])
                            os.remove(fpath2)  # удаляем физический файл
                            del value[k]  # удаляем имя файла из списка
                        else:
                            k += 1
                    i += 1

    elif cmd.upper() == 'X' or cmd == '':
        print('Работа программы окончена')
        break
    print('------------------------------')
    cmd = input('Введите следующую команду: ')
else:
    print('Команда не распознана!\nПрограмма завершает работу!')